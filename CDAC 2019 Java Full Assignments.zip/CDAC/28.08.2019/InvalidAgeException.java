// Create a class Voter(ovterId , name , age) with parameterized  constructor .
// the parameterized constructor should throw a checked exception if age is less than 18
// .The message of exception is "Invalid age for voter""

// here we have to make a coustom exception handling mechanism .

class MyException extends Exception{
    public Exception(String s){
        super(s);
    }
}
class Voter{
    int voterId ;
    String name ;
    int age ;
    Voter(int voterId , String name , int age){
        this.voterId = voterId ;
        this.name = name ;
        this.age = age ;
    }



}