import java.util.Scanner ;
class PlayerThread extends Thread {
    int num ;
    PlayerThread(int number){
        this.num = number ;
    }
    public void run(){
        for (int i = num ; i != 0 ; i--){
            System.out.println(i);
            try{
                Thread.sleep(1000);
            }catch(InterruptedException ex){
                System.out.println("Process Interuppted >>>");
            }
        }// for ends
    }// run() method ends .
} // class PlayerThread ends .

class DownloadThread extends Thread{
    int num ;
    DownloadThread(int number){
        this.num = number ;
    }
    public void run(){
        for(int i = 1 ; i <= num ; ++i){
            System.out.println(i);
            try{
                Thread.sleep(1001);
            }catch(InterruptedException ex){
                System.out.println("Process Interuppted >>>");
            }
        }
    }
}
    



public class MultiThreadingDemo {
    public static void main(String[] args) {
       System.out.println("Main Started >>>>>>");
        // try {
        //     Thread.sleep(3000);
        // }catch(InterruptedException ex){
        //     System.out.println("Main function Interuppted");
        // }
        int n ;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number ::");
        n = sc.nextInt();
        PlayerThread p = new PlayerThread(n);
        p.start();
        DownloadThread d = new DownloadThread(n);
        d.start();

        System.out.println("Thanks >>>>>>");
        sc.close();
    }
}