import java.util.MissingFormatArgumentException;

class FactorialThread extends Thread {
    int n ;
    public void run(){
        Thread t = Thread.currentThread();
        System.out.println( t );
        int f = 1 ;
        for (int i = 1 ; i<=n ;++i){
            f = f * i ;
            System.out.println("fact : - " + f);
            try{
                Thread.sleep(1000);
            }catch(InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }
}

class TableThread implements Runnable {
    int  n ; 
    public void run(){
        Thread t = Thread.currentThread();
        System.out.println( t );
        for(int i = 0 ; i<=10 ;++i){
            int tbl = n * i ;
            System.out.println("Table :: " + tbl);
            try{
                Thread.sleep(1000);
            }catch(InterruptedException ex){
                ex.printStackTrace();
            }
        }
    }
}

public class MultiThreading1 {
    public static void main(String[] args) {
        System.out.println("Main Thread >>>>>");
        Thread t = Thread.currentThread();
        System.out.println( t );
        FactorialThread ft = new FactorialThread() ;

        ft.setPriority(8);
        ft.setName("FactThread");

        ft.n = 5 ;
        ft.start();
        System.out.println("=------------------=");
        TableThread tt  = new TableThread();
        tt.n = 6 ;
        Thread t1 = new Thread(tt);
        t1.start();
///  Here our main thread  wait for threads to complete .
        try{
            ft.join();
            t1.join();
        }catch(InterruptedException ex){
            ex.printStackTrace();
        }
        System.out.println("All Processing Done !!");
    }
}