import java.util.Scanner ;

 class Product {
    static double totalPrice = 0 ;
    String name ;
    double price ;
    int quantity ;
    Product (String name , double price , int quantity){
        this.name = name ;
        this.price = price ;
        this.quantity = quantity ;
    }

    public void totalPrice (Product arr[]){
        for (int i = 0 ; i < arr.length ; i++){
            totalPrice = totalPrice + arr[i].price ;
            totalPrice = totalPrice*arr[i].quantity ;
        }
        System.out.println("Total :: " + totalPrice);
    }

    public void highestPrice(Product arr[]){
        double highest = arr[0].price ;
        for(int i = 1 ; i < arr.length ; i++){
            if(highest < arr[i].price)
                highest = arr[i].price ;
        }
        System.out.println(" Highest Price item is of :: " + highest);
    }
}

public class ProductPurchased {
    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        Product p[] = new Product[5] ;
        for(int i = 0 ; i < 5 ; i++){
            System.out.println("Enter Name of Product");
            String n = sc.next(); 
            System.out.println("Enter Price of Product");
            double rs = sc.nextDouble();
            System.out.println("Enter Quantity of Product");
            int q = sc.nextInt(); 
            p[i] = new Product(n,rs,q);
        }

        p[0].totalPrice(p);
        p[0].highestPrice(p);

        sc.close();
    }
}