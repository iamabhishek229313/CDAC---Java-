import java.util.Scanner ;

public class MathOperation1 {
    int x ;
    int y ;
    int rOfAdd ,rOfMult,rOfPow;
    public void init(int x, int y){
        this.x = x ;
        this.y = y ;
    }
    public void add(){ 
        this.rOfAdd = (this.x + this.y);
    }
    public void mult(){
        this.rOfMult = (this.x * this.y);
    }
    public void power(){
       this.rOfPow = (int)(Math.pow(this.x,this.y));
    }
    public void display(){
    System.out.println("Addition result :::" + this.rOfAdd) ;
    System.out.println("Multiplication result :::" + this.rOfMult) ;
    System.out.println("Power of " + this.x + " " +this.y+" is "+this.rOfPow) ;    
}


    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Give x :");
        int x = sc.nextInt();
        System.out.println("Give y :");
        int y = sc.nextInt();
        MathOperation1 m = new MathOperation1();
        m.init(x,y);
        m.add();
        m.mult();
        m.power();
        m.display();
        sc.close();
    }
}