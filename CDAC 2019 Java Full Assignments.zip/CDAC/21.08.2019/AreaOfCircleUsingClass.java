import java.util.Scanner ;
public class AreaOfCircleUsingClass{
    public int radius ;
    public double area ;
    public void init(int radius){
        this.radius = radius ;
    }
    public void calculateArea(){
        this.area = (3.14*this.radius*this.radius);
    }
    public void display(){

        System.out.println("Area of Circle : " + this.area);
    }
    public static void main (String[] args){
        Scanner sc  = new Scanner(System.in);
        System.out.println("Give Radius :");
        int r = sc.nextInt();
        AreaOfCircleUsingClass aofc = new AreaOfCircleUsingClass();
        aofc.init(r);
        aofc.calculateArea();
        aofc.display();
        sc.close();
    }
}