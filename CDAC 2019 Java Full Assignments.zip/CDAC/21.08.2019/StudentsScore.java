import java.util.Scanner ;
class Student {
    String name ;
    String rollno ;
    int age ;
    int score ;
    Student(String name , String rollno , int age , int score){
        this.name = name ;
        this.rollno = rollno ;
        this.age = age ;
        this.score = score ;
    } 
    void categorise(Student arr[]){
        int length = arr.length ;
        for(int i =  0 ; i < length ; i++){
            if((arr[i].score >= 0) && (arr[i].score <= 50))
                System.out.println(arr[i].name + " belongs to " + "[0-50]");
            else if ((arr[i].score>50) && (arr[i].score <= 65))
                System.out.println(arr[i].name + " belongs to " + "[51-65]");
            else if((arr[i].score>65) && (arr[i].score <= 80))
                System.out.println(arr[i].name +  "belongs to " + "[65-80]");
            else if ((arr[i].score>80) && (arr[i].score <= 100))
                System.out.println(arr[i].name +  "belongs to " + "[80-100]");
            else System.out.println("Error Ocurred !");
        }
    }
    
}

public class StudentsScore {
    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        Student s[] = new Student[10];
        for(int i = 0 ; i < 10 ; i++){
            System.out.println("Enter Name of Student");
            String name = sc.next(); 
            System.out.println("Enter Roll number");
            String rno = sc.next();
            System.out.println("Enter Age of Student");
            int age = sc.nextInt(); 
            System.out.println("Enter Score of Student");
            int score = sc.nextInt();

            s[i] = new Student(name,rno,age,score);
        }
        s[0].categorise(s);
        sc.close();
    }
}