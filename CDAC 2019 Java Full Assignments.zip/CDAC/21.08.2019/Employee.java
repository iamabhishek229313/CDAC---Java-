public class Employee{
    static int noOfemployee = 3000 ;
    static double totalSalary = 0 ;
    String name ;
    int employeeNumber ;
    double salary ;
    Employee(String name ,int empNo , double salary){
        this.name = name ;
        this.employeeNumber  = noOfemployee ;
        this.salary = salary ;
        noOfemployee++ ;
    }
    public void totalSalaryf(Employee arr[]){
        int length = arr.length ;
        for (int i = 0 ; i < length ; i++){
            totalSalary = totalSalary + arr[i].salary ;
        }
    }



    public static void main(String[] args){
        Employee a[] = new Employee[5];
        a[0] = new Employee("abhishek" , 32434 , 20000);

        a[1] = new Employee("black" , 32435 , 20002);
        
        a[2] = new Employee("berry" , 32436 , 20003);
        a[3] = new Employee("rashmi" , 32437 , 20004);
    
        a[4] = new Employee("sourabh" , 32438 , 20005);

        a[4].totalSalaryf(a);
        System.out.println("Total salary  " + Employee.totalSalary);
    }
}