import java.util.Scanner ;
 class MultiplyThroughClass {
    int multOfIntegers ;
    double multOfDoubles ;
    int multOfArrayIntegers = 1 ;
    double mulOfintAndDouble ;
//Here i have used  the concept of function over loading .
    public void multiply(int x ,int y){
        this.multOfIntegers = x * y ;
    }
    public void multiply (double x , double y){
        this.multOfDoubles = x * y ;
    }
    public void multiply(int arr[]){
        int length = arr.length ;
        for(int i = 0 ;i < length ;i++){
            this.multOfArrayIntegers = this.multOfArrayIntegers * arr[i] ;
        }
    }
    public void multiply(int x ,double y){
        this.mulOfintAndDouble = x * y ;
    }
    public void display (){
        System.out.println("Through both integers = " + this.multOfArrayIntegers);
        System.out.println("Through both doubles = " + this.multOfDoubles);
        System.out.println("Through a Array of integers = " + this.multOfArrayIntegers);
        System.out.println("Through a integer and a double = " + this.mulOfintAndDouble);

    }


    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        MultiplyThroughClass m = new MultiplyThroughClass();

        System.out.println("Give x as integer ::");
        int xInt = sc.nextInt();
        System.out.println("Give y as integer ::");
        int yInt = sc.nextInt();

        m.multiply(xInt,yInt);

        System.out.println("Give x as double ::");
        double xDob = sc.nextDouble();
        System.out.println("Give y as double ::");
        double yDob = sc.nextDouble();

        m.multiply(xDob,yDob);

        int arr[] = {2,4,5,6};
        m.multiply(arr);

        System.out.println("Give x as int ::");
        int x1int = sc.nextInt();
        System.out.println("Give y as double ::");
        double y1Dob = sc.nextDouble();

        m.multiply(x1int,y1Dob);

        m.display();
        sc.close();
    }
}