import java.util.scanner ;
class CollectionFramework {
    public static void main (String[] args){

    }
}