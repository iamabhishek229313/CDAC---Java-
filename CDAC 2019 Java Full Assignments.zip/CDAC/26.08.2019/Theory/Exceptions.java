import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner ;
class Exceptions{
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);

        // int arr[]  =  {12,34,56,67};
        
        // try{
        //     System.out.println("Element is - " + arr[5]);
        // }catch(ArrayIndexOutOfBoundsException ex){
        //     System.out.println("Array Index is not valid ");
        //     System.out.println(ex);
        // }

        // try{
        //     int a = sc.nextInt();
        //     int b = sc.nextInt();

        //     int result = a / b ;
        //     System.out.println("Result is " + result);
        //     sc.close();
        //     return ;
        // }catch(ArithmeticException ex){
        //     System.out.println("You can't divide any integer with Zero");
        //     System.out.println(ex);
        // }

        // finally{ // It guarantes that code inside this will execute .Comes after the try and catch statement 
        //     System.out.println("Thanks See you again !");
        // }

        

        // System.out.println("Thanks !!");

        // Upper part is for uncchecked Exception .


        // now for Checked Exception ---------------

        File f = new File("C:\\Users\\Gallery\\a.txt");
        try{
        FileWriter writer = new FileWriter(f);
        writer.write("Hello Everyone");
        writer.close();
        }catch(IOException ex){
            System.out.println("This is IO exception " + ex);
        }
        sc.close();
    }
}