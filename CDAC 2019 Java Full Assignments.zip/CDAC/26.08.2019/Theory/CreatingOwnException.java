import java.util.Scanner ;
class RegistrationException extends Exception{
    public RegistrationException(String msg){
        super(msg);
    }
}
class VoterRegistration{
    void register(String name , int age , String address) throws RegistrationException{
         if(age<18){
             RegistrationException regEx = new RegistrationException("Age is low as required to ");
            throw regEx ;
         }else{
             System.out.println("Registration Successfull");
         }
    }
}


class CreatingOwnException{
    public static void main(String[] args) {
        VoterRegistration vr = new VoterRegistration();
        try {
            vr.register("Ankur", 11 , "Bhbaneshwar" );
        }catch(RegistrationException e){
            System.out.println("Age not valid");
        }

        System.out.println("Thanks !");
    }
}