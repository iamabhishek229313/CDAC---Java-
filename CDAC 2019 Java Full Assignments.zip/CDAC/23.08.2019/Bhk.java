import java.util.Scanner;
class OneBHK{
    double roomArea ;
    double hallArea ;
    double price ;
    OneBHK(){ // Default Constructor .

    }
    OneBHK(double roomArea ,double hallArea ,double price){
        //Parameterized Constructor 
        this.roomArea = roomArea ;
        this.hallArea = hallArea ;
        this.price  = price ;
    }

    void show(){
        System.out.println("Room Area -  " +this.roomArea);
        System.out.println("Hall Area -  " +this.hallArea);
        System.out.println("Price -  " +this.price);
    }
}

class TwoBHK extends OneBHK{
    double room2Area;
    TwoBHK(){ // Default Constructor 

    }

    TwoBHK(double roomArea ,double hallArea ,double price ,double room2Area){
        super(roomArea,hallArea,price);
        this.room2Area = room2Area ;
    }
    void show(){
        super.show();
        System.out.println("Room 2 Area -  " +this.room2Area);
    }

    void totalPrice (TwoBHK arr[]){
        double total  = 0 ;
        for (int i= 0 ;i<arr.length;i++){
            total = total + arr[i].price;
        }
        System.out.println("Total price is = " + total);
    } 
}



public class Bhk {
    public static void main(String[] args){
        Scanner sc = new Scanner (System.in);

        TwoBHK tb[] = new TwoBHK[3];
        for(int i =0 ;i < tb.length ;i++){
            System.out.println("Give Room Area ");
            double rA = sc.nextDouble();
            System.out.println("Give hall Area ");
            double hA = sc.nextDouble();
            System.out.println("What is price ? ");
            double rs = sc.nextDouble() ;
            System.out.println("Give Room  2  Area ");
            double r2A = sc.nextDouble();
            tb[i] = new TwoBHK(rA,hA,rs,r2A);
        }
        System.out.println("--------------Information---------- ");
        for(int i =0 ;i < tb.length ;i++){
            tb[i].show();
            System.out.println("----------------------------- ");

        }
        tb[0].totalPrice(tb);

        sc.close();
    }
}