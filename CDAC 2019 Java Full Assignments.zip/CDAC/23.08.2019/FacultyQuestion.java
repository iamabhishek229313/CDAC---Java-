import java.util.Scanner ;

class Faculty {
    int facultyId ;
    double salary ;
    protected Scanner sc = new Scanner(System.in);
    Faculty(double tsalary){
        this.salary = tsalary ;
        System.out.println("Total Salary = " + this.salary);
    }
    void getFacultyid (){
        System.out.println("Give Faculty Id ::");
        int facultyId = sc.nextInt();
        this.facultyId = facultyId ;
    }
    void display(){
        System.out.println("Faculty Id is ::" + this.facultyId);
        System.out.println("Faculty Salary is ::" + this.salary);
    }
}

class FullTimeFaculty extends Faculty{
    double basic , allowances ;
    FullTimeFaculty(double basic , double allowances){
        super(basic+allowances);
        this.basic = basic ;
        this.allowances = allowances ;
    }
}

class PartTimeFaculty extends Faculty{
    double hour , rate ; 
    PartTimeFaculty(double hour , double rate){
        super(hour*rate);
        this.hour = hour ;
        this.rate = rate ;
    }
}

public class FacultyQuestion{
    public static void main (String[] args){
        FullTimeFaculty f[] = new FullTimeFaculty[2];
        PartTimeFaculty p[] = new PartTimeFaculty[2];

        f[0] = new FullTimeFaculty(200.0,89000);
        f[1] = new FullTimeFaculty(3786.0,86700);
        p[0] = new PartTimeFaculty(8,2368);
        p[1] = new PartTimeFaculty(9,867);

        f[0].getFacultyid();
        f[1].getFacultyid();
        p[0].getFacultyid();
        p[1].getFacultyid();

        f[0].display();
        f[1].display();
        p[0].display();
        p[1].display();
    }
}