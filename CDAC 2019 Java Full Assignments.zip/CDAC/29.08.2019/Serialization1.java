import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.ObjectInputStream;
 
class Employee implements Serializable{
    public int eId ;
    public String eName ;
    Employee(int empId , String empName){
        this.eId = empId;
        this.eName = empName ;
    }
    @Override
    public String toString(){
        return "Employee [ Employee ID -" + eId + "  ,  " + "Employee Name -" + eName + "]" ;
    }
}

class Serialization1  {
    public static void main(String[] args) throws IOException , ClassNotFoundException {
        Employee e = new Employee(104, "Abhishek Rai");

        FileOutputStream fos = new FileOutputStream("E://CDAC//29.08.2019//Serialization1.txt") ;
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(e);
        System.out.println("Sucess");
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("E://CDAC//29.08.2019//serialization1.txt"));
        Employee e1 = (Employee)ois.readObject();
        System.out.println(e1);
        ois.close();
    }
}