import java.util.Scanner ;

class Star extends Thread{
    int n ;
    Star(int n){
        this.n = n ;
    }
    @Override
    public void run(){
        for(int i = 0 ;i < n ;++i){
            for(int j = i ; j<n ;j++){
                System.out.print("*");
            }
            try{
                Thread.sleep(1000);
            }catch(InterruptedException ex){
                ex.printStackTrace();
            }
            System.out.println(" ");
        }
    }
}

class MultiThreadingStar {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the lines to Print");
        int lines  = sc.nextInt();
        Star s = new Star(lines);
        s.start();
        sc.close();
    }
}