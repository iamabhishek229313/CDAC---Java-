import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

class Demo2 {
    public static void main(String[] args) throws IOException{
        FileOutputStream fos = new FileOutputStream("E://CDAC//29.08.2019//demo2.txt");
        DataOutputStream dos = new DataOutputStream(fos);
        dos.writeChar(67);
        dos.close();
        fos.close();
    }
}