import java.util.Scanner ;

import javax.swing.plaf.synth.SynthOptionPaneUI;

class Prime implements Runnable {
    int n ;
    Prime(int n){
        this.n = n ;
    }
    @Override
    public void run(){
        int c = 0 ;
        for(int i = 2 ; i < n/2 ; ++i){
            if(this.n%i == 0){
                c++;
                break;
            }
        }
        if(c == 0){
            System.out.println("Given Number is Prime ");
        }else{
            System.out.println("Given Number is Not Prime ");
        }
    }
}

class WetherPrimeOrNotUsingRunnable{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number to check ");
        int number  = sc.nextInt();
        Thread t = new Thread(new Prime(number));
        t.start();
        sc.close();
    }
}