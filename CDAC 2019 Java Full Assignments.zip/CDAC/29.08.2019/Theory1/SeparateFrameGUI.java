import javax.swing.* ;
import java.awt.*;
import java.awt.event.*;
import java.io.* ;

class StudentInfoFrame extends JFrame {
    JTextField fieldName ;
    JRadioButton radioMale, radioFemale ;
    JComboBox<String> comboCourse ;
    JCheckBox feeCheckBox ;
    JButton buttonSave ;
    JLabel labelResult;
    ButtonGroup bgroup ;
    String courseArray[] = {"B.Tech -cse" , "MBA-HR" , "MCA"};

    public StudentInfoFrame(){
        setLayout(new FlowLayout());
        setSize(400,400);
        getContentPane().setBackground(Color.CYAN);
        //Create object of all above UI Component .
        fieldName = new JTextField("Enter your name :: ");
        radioMale = new JRadioButton("Male");
        radioFemale = new JRadioButton("Female");
        

        comboCourse = new JComboBox<String>(courseArray);
        feeCheckBox = new JCheckBox("IsFeePaid");
        buttonSave = new JButton("SAVE");
        labelResult = new JLabel("Data Result ..............");

        add(fieldName);
        add(radioMale);
        add(radioFemale);
        add(feeCheckBox);
        add(comboCourse);
        add(buttonSave);
        add(labelResult);
        bgroup = new ButtonGroup();
        bgroup.add(radioMale);
        bgroup.add(radioFemale);
        // Create SAVE button listener ,

        class SaveClickListener implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent e){
                // Collect data and display on result label .
                String name = fieldName.getText();
                String gender = "Male" ;

                if(radioFemale.isSelected()){
                    gender = "Female" ;
                }
                String feeStatus = "un paid" ;

                if(feeCheckBox.isSelected()){
                    feeStatus = "paid";
                }

                String course ="" ;
                int selPos = comboCourse.getSelectedIndex();
                course = courseArray[selPos];

                // Combine all sta in the string 
                String str = name + " - " + gender+ " - " +course + " - " + feeStatus ;
                labelResult.setText(str);
                try{
                    FileOutputStream fos = new FileOutputStream("E://CDAC//29.08.2019//Theory1//data.txt");
                    ObjectOutputStream oos = new ObjectOutputStream(fos);
                    oos.writeChars(str);
                    
                    oos.close();
                    fos.close();
                }catch(IOException ex){
                    System.out.println("Interuupted : == =" + ex);
                }  
            }
        }
        SaveClickListener listener = new SaveClickListener() ;
        buttonSave.addActionListener(listener);
    }
}

class SeparateFrameGUI{
    public static void main(String[] args){
        StudentInfoFrame s = new StudentInfoFrame();
        s.setVisible(true);
    }
}