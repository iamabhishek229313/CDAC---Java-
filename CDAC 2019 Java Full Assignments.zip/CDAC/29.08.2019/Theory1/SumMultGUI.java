import javax.swing.*;
import java.awt.*; //Abstract window toolkit 
import java.awt.event.*;

class SumMultGUI {
    public static void main(String[] args){
        JFrame frame1 = new JFrame();
        frame1.setSize(400,400);
        frame1.setLayout(new FlowLayout());

        JLabel heading = new JLabel("FOR SUM CALCULATION");
        frame1.add(heading);

        JTextField field1 = new JTextField("Enter First Number");
        frame1.add(field1);
        JTextField field2 = new JTextField("Enter Second Number");
        frame1.add(field2);

        JButton sumButton = new JButton("SUM");
        frame1.add(sumButton);

        JLabel resultLabel = new JLabel("Result - ");
        frame1.add(resultLabel);

        class SumClickListener implements ActionListener{
            @Override
            public void actionPerformed(ActionEvent e){
                // Fetching data from the fields
                String str1 = field1.getText();
                int a = Integer.parseInt(str1);
                String str2 = field2.getText();
                int b = Integer.parseInt(str2);

                int c = a + b ;
                resultLabel.setText("Result - "+c);
            }
        }
        SumClickListener s = new SumClickListener();
        sumButton.addActionListener(s);


        ////////////////////////////////

        JLabel heading2 = new JLabel("FOR MULTIPLY CALCULATION");
        frame1.add(heading2);

        JTextField field1_2 = new JTextField("Enter First Number");
        frame1.add(field1_2);
        JTextField field2_2 = new JTextField("Enter Second Number");
        frame1.add(field2_2);

        JButton multButton = new JButton("MULTIPLY");
        frame1.add(multButton);

        JLabel resultLabel_2 = new JLabel("Result - ");
        frame1.add(resultLabel_2);

        class MultClickListener implements ActionListener{
            @Override
            public void actionPerformed(ActionEvent e){
                // Fetching data from the fields
                String str1 = field1_2.getText();
                int a = Integer.parseInt(str1);
                String str2 = field2_2.getText();
                int b = Integer.parseInt(str2);

                int c = a * b ;
                resultLabel_2.setText("Result - "+c);
            }
        }
        MultClickListener m = new MultClickListener();
        multButton.addActionListener(m);
        frame1.setVisible(true);
    }
}