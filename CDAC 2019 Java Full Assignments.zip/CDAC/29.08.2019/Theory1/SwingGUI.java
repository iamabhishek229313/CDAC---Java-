import java.awt.FlowLayout;
import javax.swing.*;
class SwingGUI {
    public static void main(String[] args){
        JFrame frame1 = new JFrame();
        frame1.setSize(400,500);
        frame1.setLayout(new FlowLayout());
        

        JLabel label = new JLabel("WELCOME TO GUI");
        frame1.add(label);

        JTextField tf = new JTextField("Enter your name :: ");
        frame1.add(tf);

        JButton button = new JButton("Click there !");
        frame1.add(button);

        JRadioButton radioButton = new JRadioButton("Radio Button");
        frame1.add(radioButton);

        JCheckBox checkBox = new JCheckBox ("CheckBox");
        frame1.add(checkBox);
        frame1.setVisible(true);
    }
}