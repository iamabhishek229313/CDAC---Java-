abstract class TwoDShape{
    float area ;
    float perimeter ;
    String shapeName ;
    
    void display(){
        System.out.println(shapeName + " - " + area + " - " + perimeter);
    }
    abstract void findArea();
    abstract void findPerimeter();
}
//-----------IS----A---realtionship .
class Circle extends TwoDShape{
// Note : - All the abstract methods in the parent class should be implemented 
// through child at one time means the closest child have to implement all of the abstract methods inside that 
// abstract parent class .
    float radius ;
    Circle(){
        shapeName = "Cirlce" ;
    }

    void findArea(){
        area = 2 * 3.14f * radius ; 
    }

    void findPerimeter(){
        perimeter = 2 * 3.14f * radius ;
    }
}

public class AbstractClasses {
    public static void main(String[] args){
        Circle c1 = new Circle();
        c1.radius = 15 ;
        c1.findArea();
        c1.findPerimeter();
        c1.display();
    }
}