class Student { //Outer
    int rollno ;
    String name ;
    Address localAd , permanaentAd;
    ResultData result ;

    class Address { // member inner class .
        String city ;
        int pincode ;
        String state ;
        String street ;
    }

    static class ResultData { //Static inner class
        String course ;
        int sem ;
        float cgpa ;
        void display(){
            System.out.println(course+"-"+sem+"-"+cgpa);
        }
    }

    void display(){
        System.out.println(rollno+"-"+name);
        System.out.println(localAd.city + "-" +localAd.pincode + "-" + localAd.street);
        System.out.println(permanaentAd.city + "-" +permanaentAd.pincode + "-" + permanaentAd.street);
        result.display();
    }

    void showGrad(){
        class GradCalculator{ // local inner class
            void findGrade(){
                if(result.cgpa > 8.0){
                    System.out.println("A Grade ");
                }else if (result.cgpa >6.0 && result.cgpa <8.0){
                    System.out.println("B Grade");
                }else{
                    System.out.println("C Grade");
                }
            }
        }
        GradCalculator g = new GradCalculator ();
        g.findGrade();
    }

    void setAddress(){
        localAd = new Address();
        localAd.city = "BhubaneshWAR";
        localAd.pincode =752054;
        localAd.street = "Mahura";

        permanaentAd = new Address();
        permanaentAd.city = "Ranchi" ;
        permanaentAd.pincode = 834002 ;
        permanaentAd.street = "Haider Ali Road" ;
    }
}

public class InnerClasses {
    public static void main (String[] args){
    Student s1 = new Student(); //Referncing to whole Student class .
    s1.rollno = 101 ; // Accessing the data memebers .
    s1.name = "Abhishek" ; // Accessing another data member .
    s1.setAddress(); // Calling a method in Student class that first makes a Object of its own member inner class and then assigning the values to the data members inside that member inner class .
    s1.result = new Student.ResultData(); // Making Student data member that is of type static class ResultData that means we have to fisrt make the object to tthat class 

    s1.result.course = "B.Tech (cse)";
    s1.result.sem = 3 ;
    s1.result.cgpa = 9.5f ;
    s1.result.course = "M.tech";
    s1.display();
    s1.showGrad();
    }
}