class A {
    int x ;
    void square(){
        System.out.println(x*x);
    }
}

class B extends A {
    int y ;
    void multiply()
    {
        System.out.println(x*y);
    }
}

public class Inheritance {
    public static void main (String[] args){
        A a1 = new A();
        a1.x = 4 ;
        a1.square();
    // Now we are making a new object B that is the instance of class B()
        B  b1 = new B();
    // We have assigned the value that inherited from the class A() as x
        b1.x = 5 ;
    // Accessing the value y child class B()
        b1.y = 3 ;
    // Now we have used the method that is inherited from class A() and we have accessed that method through the class B() by first inherited from the class A()
        b1.square();
    // Now we have used method of the class B() 
        b1.multiply();
    }
}