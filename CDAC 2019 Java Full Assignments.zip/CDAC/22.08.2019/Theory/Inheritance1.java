// Role of constructoer in inheritance .

class P {
    int i ;
    P(){
        System.out.println("P default");
    } 
    P(int i){
        System.out.println("P Parameterized");
        this.i = i ;
    }
}

class Q extends P {
    int j ;
    Q(){
        System.out.println("Q default");
    }
    Q(int i , int j){
        this.i = i ; // We have changed the value of the integer i that 
        // is declared at the class P .
        this.j = j ;
        System.out.println("Q parameterized");
    }
}

// Multilevel Inheritance .
class R extends Q {
    int k ;
    R(){
        System.out.println("R default");
    }
    R(int i , int j , int k){
         // this.i = i ;
         // this.j = j ;
        super(i,j); // Here we are passing the variables to the super class 
        // that is class Q through parameterized constructor .
        this.k = k ;
        System.out.println("R parameterized");
    }
}

public class Inheritance1{
    public static void main (String[] args){
        P p1 = new P();
        //-----
        Q q1 = new Q();
        //-----
        R r1 = new R();
        //-----

        System.out.println("---------------------------");

        Q q2 = new Q(2,5);

        System.out.println("----------------------------");

        R r2 = new R(1,2,3);
    }
}