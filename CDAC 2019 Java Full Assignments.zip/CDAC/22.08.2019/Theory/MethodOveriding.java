class Square{
    float length; 
    void display(){
        System.out.println("Side-" + length);
    }
    float getArea(){
        float a  = length * length ;
        return a ;
    }
} 

class Rectangle extends Square{
    float breadth ;
    void display(){ //Method Overriding .
        system.out.println(length +"-"+breadth);
        //super.display();
    }
    float getArea(){
        float a = length * breadth ;
        return a ;
    }
}

public class MethodOveriding{
    public static void main (String[] args){
        Square sq = new Square();
        sq.length = 5 ;
        sq.display();
        float a = sq.getArea(); // Returns  : 5*5 = 25
        System.out.println("Area of square" + a);

        Rectangle rect1 = new Ractangle();

        rect1.length = 6 ;
        rect1.breadth = 4 ;
        float b = rect1.getArea(); // Returns  : 6 * 4 = 24

        System.out.println("Area of rectangle " + b);
    }
}