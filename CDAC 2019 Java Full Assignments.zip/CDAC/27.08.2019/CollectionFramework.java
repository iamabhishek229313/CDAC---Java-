// import java.util.Queue;
// import java.util.ArrayList;
import java.util.*;
// import java.util.List;

class Student {
    int rollno;
    String name ;
    public String toString(){ 
// Why would we override the toString() method ?
// The toString() method return the string representation of the Object . 
// If we want to print any object , java Compiler internally invokes the
// toString() method and hence returns the desired  output , it can be 
// state of  of an object etc .
        String str  = name  + "-" + rollno ;
        return str ;
    }

    public boolean equals(Student obj){
        if(this.rollno == obj.rollno){
            return true;
        }else return false ;
    }

    Student(){

    }
    Student(int rollno , String name){
        this.rollno = rollno ;
        this.name = name ;
    }
}


class CollectionFramework {
    public static void main(String[] args) {
        Collection c ;
        List list1 ;
        //Queue queue1 ;

        ArrayList list2  = new ArrayList(); // makes a dynamic  array of a non- gneric type .

        list2.add(15);
        Integer i = 34 ;
        list2.add(i);
        list2.add("abhishek");
        list2.add(52.9);
        list2.add(false);

        System.out.println(list2);

        System.out.println(list2.size()); // Will print the size of the given ArrayList 

        Student s1 = new Student(007,"Abhishek Rai");
        list2.add(s1);

        System.out.println(list2);
        list2.remove(2) ; // uses the index as the parameter .
        System.out.println(list2);

        Object o = list2.get(4);
        System.out.println(o);

        Object str  = list2.get(4);

        if(str instanceof Student){
            Student st = (Student)str;
            System.out.println(st.rollno);
        }
    }
}