import java.util.Scanner ;

abstract class Processor{
    int data ;
    abstract void processor();
    abstract void showData();
}
class Factorial extends Processor{
    Factorial(int number){
        this.data = number ;
    }
    void processor(){
        int fact = 1 ;
        if(this.data == 0 ){
            System.out.println("Factorial of " + this.data + " is " + fact);
        }else{
            int x = this.data ;
            while(x != 0){
                fact  = fact * x ;
                x = x - 1 ;
            }
            System.out.println("Factorial of " + this.data + " is " + fact);
        }
    }
    void showData(){
        
    }
}

class Circle extends Processor {
    Circle(int radius){
        this.data = radius;
    }
    void processor(){
        double area = (3.14 * this.data * this.data) ; 
        System.out.println("Area of Circle  is " + area);
    }
    void showData(){

    }
}
public class ProcessData{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int choice ;
        int data ;
        while(true){
            System.out.println(" 1 . Factorial of a number ");
            System.out.println(" 2. For Area of Cirlce ");
            System.out.println("Enter your choice");
            choice = sc.nextInt();
            switch(choice){
                case 1 :
                    System.out.println("Enter a number ");
                    data  = sc.nextInt();
                    Factorial f = new Factorial(data);
                    f.processor();
                    break;
                case 2 :
                    System.out.println("Enter the radius ");
                    data = sc.nextInt();
                    Circle c = new Circle(data);
                    c.processor();
                    break;
                default:
                    System.out.println("Wrong Choice !");
            }
            break;
        }
        sc.close();
    }
}