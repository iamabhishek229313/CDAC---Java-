import java.util.Scanner ;

class Student {
    int roll ;
    double percentage ;
    Student(){ //Deafault constructor

    }
    Student(int roll , double percentage){
        this.roll = roll ;
        this.percentage = percentage ;
    }
    void display (){

    }
}

class CollegeStudent extends Student{
    int semester ;
    CollegeStudent(){

    }

    CollegeStudent(int rollno , double percentage , int semester){
        super(rollno , percentage);
        this.semester = semester ;
    }

    void show(CollegeStudent arr[]){
        int count = 0 ;
        System.out.println("---------College Students Data -------");
        for(int i = 0 ;i < arr.length ;++i){
            System.out.println("Roll No" + arr[i].roll);
            System.out.println("Percentage " + arr[i].percentage);
            System.out.println("Semester is" + arr[i].semester);
            if(arr[i].percentage > 75){
                count++;
            }
        }
        System.out.println("No of College students having percentage more than 75 ::  " + count );
    }
}

class SchoolStudent extends Student {
    String className ;
    SchoolStudent(){

    }
    SchoolStudent(int rollno , double percentage , String className){
        super(rollno,percentage);
        this.className = className ;
    }

    void show(SchoolStudent arr[]){
        int count = 0 ;
        System.out.println("---------School Students Data -------");
        for(int i = 0 ;i < arr.length ;++i){
            System.out.println("Roll No" + arr[i].roll);
            System.out.println("Percentage " + arr[i].percentage);
            System.out.println("Class Name " + arr[i].className);
            if(arr[i].percentage > 75){
                count++;
            }
        }
        System.out.println("No of School students having percentage more than 75 ::  " + count );
    }
}

public class StudentsQuestion {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        CollegeStudent cs[] = new CollegeStudent[3];
        SchoolStudent ss[] = new SchoolStudent[2];
        System.out.println("Enter College students  Data");
        for(int i = 0 ;i < 3 ; i++){
            System.out.println("Give Roll No ");
            int rn = sc.nextInt();
            System.out.println("Give Percentage ");
            double pcnt = sc.nextDouble();
            System.out.println("Enter Semester ");
            int sem = sc.nextInt();

            cs[i] = new CollegeStudent(rn,pcnt,sem);
        }
        System.out.println("Enter School Students Data");
        for(int i = 0 ;i < 2 ; i++){
            System.out.println("Give Roll No ");
            int rn = sc.nextInt();
            System.out.println("Give Percentage ");
            double pcnt = sc.nextDouble();
            System.out.println("Enter Class name ");
            String clsname = sc.next();

            ss[i] = new SchoolStudent(rn,pcnt,clsname);
        }

            cs[0].show(cs);
            ss[0].show(ss);
        System.out.println("For Query ");
        int query = sc.nextInt();
        for(int i = 0 ;i < 3 ; i++){
            if(cs[i].roll == query){
                System.out.println("College Student !");
                break ;
            }
        }
        for(int i = 0 ;i < 2 ; i++){
            if(ss[i].roll == query){
                System.out.println("School Student !");
                break ;
            }
        }
        sc.close();
     }
}