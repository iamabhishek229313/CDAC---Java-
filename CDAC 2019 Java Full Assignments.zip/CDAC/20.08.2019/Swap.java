import java.util.Scanner ;
public class Swap {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter two numbers ::");
        int a , b ,temp ;
        a = sc.nextInt();
        b = sc.nextInt();
        System.out.println("Before swapping a = " + a );
        System.out.println("Before swapping b = " + b );
        a = a^b ;
        b = a^b ;
        a = a^b ;
        System.out.println("Before swapping a = " + a );
        System.out.println("Before swapping b = " + b );
    }
}