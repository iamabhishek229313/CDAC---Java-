import java.util.Scanner ;
public class Date{
    public static void main (String[] args){
        Scanner sc = new Scanner(System.in); 

        int days , years , month ,daysLeft;
        System.out.println("Enter number of days ");
        days = sc.nextInt();
        years = (days/365) ;
        month = (days -365*years)/30  ;
        daysLeft = days - month*30 - years*365 ;
        System.out.println("Year(s) :"+years);
        System.out.println("Month(s) :"+month);
        System.out.println("Day(s) :"+daysLeft);
        sc.close();
    }
}