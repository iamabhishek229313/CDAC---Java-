import java.util.Scanner ;
public class Reverse{
    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        int num ,last ;
        int mult =0 ;
        int reversedNum = 0 ;
        System.out.println("Enter your number ");
        num = sc.nextInt();

        while(num>0){
            last = num%10 ;
            reversedNum =reversedNum*10 + last;
            num = num/10 ;
        }
        System.out.println("Reversed number ::" + reversedNum);
        sc.close();
    }
}