import java.util.Scanner ;
public class Celsius{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        double fahrenheit ; double celsius ;
        System.out.println("Enter Temperature in Fahrenheit :: ")
        fahrenheit = sc.nextDouble() ;
        celsius =  5 * (fahrenheit - 32) / 9 ;
        System.out.println(celsius + "* C");
        sc.close();
    }
}