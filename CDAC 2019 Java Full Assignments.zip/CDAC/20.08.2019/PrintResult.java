import java.util.Scanner;
class PrintResult {
    public static void main(String[] args){
        int x  , y ,z ;
        Scanner sc = new Scanner(Sytem.in);
        System.out.println("Enter the value of x ::");
        x = sc.nextInt();
        y = (x*x) + 3*x - 7;
        
    }
}