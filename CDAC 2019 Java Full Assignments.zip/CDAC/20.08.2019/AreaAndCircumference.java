import java.util.Scanner ;

public class AreaAndCircumference {
    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        int radius ;
        double area ,circumference ;
        System.out.println("Enter the radius of the cirlcle ::");
        radius = sc.nextInt();

        area = 3.14 * radius * radius ;
        System.out.println("Area of the cirlcle ::" + area);

        circumference = 2 * 3.14 * radius ;
        System.out.println("Circumference of the cirlcle ::" + circumference);
        sc.close();
    }
}