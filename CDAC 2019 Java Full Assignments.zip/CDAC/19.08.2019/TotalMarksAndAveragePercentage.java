import java.util.Scanner;

public class TotalMarksAndAveragePercentage {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        float Physics, Math, Hindi, English, Chemistry;
        float totalMarks;
        float averageMarks;
        System.out.println("Marks obtained in Physics");
        Physics = sc.nextFloat();

        System.out.println("Marks obtained in Math");
        Math = sc.nextFloat();
        System.out.println("Marks obtained in Hindi");
        Hindi = sc.nextFloat();

        System.out.println("Marks obtained in English");
        English = sc.nextFloat();

        System.out.println("Marks obtained in Chemistry");
        Chemistry = sc.nextFloat();

        System.out.println("Total marks Obtained :: ");
        totalMarks = Physics + Math + Hindi + English + Chemistry;

        System.out.println(totalMarks);

        System.out.println("Average Marks :: ");

        averageMarks = (Physics + Math + Hindi + English + Chemistry) / 5;

        System.out.println(averageMarks);

        sc.close();
    }
}