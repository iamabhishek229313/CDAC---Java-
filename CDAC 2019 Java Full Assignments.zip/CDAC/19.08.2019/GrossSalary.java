import java.util.Scanner ;
public class GrossSalary {
    public static void main (String [] args){
        Scanner sc = new Scanner(System.in);

        int BS , DA ,TA ;
        int GS ;

        System.out.println("What's your BS ::");
        BS = sc.nextInt();

        System.out.println("What's your DA ::");
        DA = sc.nextInt();

        System.out.println("What's your TA ::");
        TA = sc.nextInt();

        System.out.println("Your GS");
        GS = BS + DA + TA;

        System.out.println(GS);

        sc.close();
    }
}