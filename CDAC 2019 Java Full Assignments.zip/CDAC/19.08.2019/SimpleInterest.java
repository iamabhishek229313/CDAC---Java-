import java.util.Scanner ;
public class SimpleInterest {
    public static void main (String [] args){
        Scanner sc = new Scanner(System.in);

        int principal , months ;
        float  rate  ;
        double SI ;

        System.out.println("What's your Principal ::");
        principal = sc.nextInt();

        System.out.println("What's your Rate of Interest ::");
        rate = sc.nextFloat();

        System.out.println("For Months ::");
        months = sc.nextInt();

        System.out.println("Simple Interest");
        SI = (principal * rate * months) / 100 ;

        System.out.println(SI);

        sc.close();
    }
}