import java.util.Scanner ;

public class SquareOfGivenNumber{
    public  static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter your number :: ");
        int num , sqauredNumber ;

        num = sc.nextInt();

        sqauredNumber = num * num ;

        System.out.println(sqauredNumber);

        sc.close() ;
    }
}