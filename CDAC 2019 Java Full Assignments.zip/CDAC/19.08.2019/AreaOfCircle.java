import java.util.Scanner ;
public class AreaOfCircle {
    public static void main (String [] args){
        Scanner sc = new Scanner(System.in);

        int base , height; double resultArea ;

        System.out.println("What's your traingle base ::");
        base = sc.nextInt();

        System.out.println("What's your traingle height ::");
        height = sc.nextInt();

        resultArea = (1.0/2.0)*base*height ;

        System.out.println("Area of your Triangle");
        System.out.println(resultArea);

        sc.close();
    }
}