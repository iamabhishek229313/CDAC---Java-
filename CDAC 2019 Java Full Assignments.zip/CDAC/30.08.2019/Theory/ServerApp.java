import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.* ;
import java.awt.*;
import java.awt.event.*;
import java.io.* ;

import java.net.SocketAddress;

import javax.swing.JFrame;
import javax.swing.JLabel;
class MyServer extends Thread {
    private ServerSocket ssSocket ; 

    public void run(){
        System.out.println("Server Started >>>>");
        System.out.println("Waiting for Connection >>>>>>>>>>");
        try{
            ssSocket = new ServerSocket(5678); //5678 is a port number .
            Socket dataSocket = ssSocket.accept();

            System.out.println("Client Request Accepted !");
            SocketAddress ad = dataSocket.getRemoteSocketAddress();
            System.out.println("Client : :  " + ad);
            
            //send message to the client 
            OutputStream out = dataSocket.getOutputStream();
            DataOutputStream dataOut = new DataOutputStream(out);

            dataOut.writeUTF("Hello Client , How are you ?");
            dataOut.flush();
            dataOut.close();
            dataSocket.close();

        }catch(IOException ex){
            ex.printStackTrace();
        }
    }
}

class ServerApp {
    public static void main(String[] args){
        JFrame frame = new JFrame();
        frame.setSize(400,400);
        frame.setLayout(new FlowLayout());
        //getContentPane().setBackground(Color.BLUE);

        JLabel heading  = new JLabel("_____WELCOME TO SERVER GUI_____");
        frame.add(heading);

        JButton button  = new JButton(" START SERVER ") ;
        frame.add(button);

        JLabel status = new JLabel("Status :: Offline " );
        frame.add(status);

        class ServerClickListener implements ActionListener{
            @Override 
            public void actionPerformed(ActionEvent e){
                MyServer server = new MyServer() ;
                status.setText("Status :: Online " );
                server.start();
            }
        }
        ServerClickListener listener = new ServerClickListener();
        button.addActionListener(listener);
        frame.setVisible(true);
    }
}


