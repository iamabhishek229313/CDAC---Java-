import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.* ;
import java.awt.*;
import java.awt.event.*;
import java.io.* ;

import java.net.SocketAddress;

import javax.swing.JFrame;
import javax.swing.JLabel;
class ClientApp {
    public static void main (String[] args){
        String  serverName = "127.0.0.1" ;
        int port = 5678 ;
        System.out.println("Client Started >>>>>>");
        System.out.println("Requesting  : : " + serverName);
        
        JFrame frame = new JFrame();
        frame.setSize(400,400);
        frame.setLayout(new FlowLayout());

        JLabel heading = new JLabel("THIS IS CLIENT SIDE");
        frame.add(heading);

        JButton button = new JButton("Connect");
        frame.add(button);

        JLabel status = new JLabel("Status :: Disconnected");
        frame.add(status);

        class ClientClickListener implements ActionListener{
            @Override
            public void actionPerformed(ActionEvent e){
            try {
                Socket dataSocket = new Socket(serverName,port);
                System.out.println("Server Connected !");
                //get message sent from server .
                InputStream in = dataSocket.getInputStream();
                DataInputStream dataIn = new DataInputStream(in);
                String msg = dataIn.readUTF();

                System.out.println("Message from Server ->> "  + msg );
                dataIn.close();
                dataSocket.close();
                status.setText("Status :: Connected");
            }catch(IOException ex){
                ex.printStackTrace();
            }
            }
        }
        ClientClickListener listener = new ClientClickListener();
        button.addActionListener(listener);

        frame.setVisible(true);
    }
}