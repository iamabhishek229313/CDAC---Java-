package campus.academics ;
import campus.data.* ;
public class Faculty extends Person {
    public String facultyId ;
    public String name ;
    public int salary ;
    public String branch ;
    public Faculty(String facultyId , String name , int salary , String branch){
        super() ;
        this.facultyId = facultyId ;
        this.name = name ;
        this.salary = salary ;
        this.branch = branch ;
    }
}