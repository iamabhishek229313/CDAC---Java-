package campus.academics ;
import campus.data.*;  
public class Student extends Person{
    public int rollNo ; 
    public String branch ;
    public int sem ;
    public Student(int rollNo , String branch , int sem){
        super();
        this.rollNo = rollNo ;
        this.branch = branch ;
        this.sem = sem ;
    }
}