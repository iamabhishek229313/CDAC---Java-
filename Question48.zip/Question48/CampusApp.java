import java.util.Scanner;
import campus.academics.* ;
public class CampusApp {
    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        String facultyID , name , branch ;
        int salary ;
        Faculty f[] = new Faculty[5];
        System.out.println("Give Information about 5 faculty :: ");
        for(int i = 0 ; i < 5 ; ++i){
            System.out.println("Faculty id of  " + (i+1) + "  faculty");
            facultyID = sc.nextLine() ;
            System.out.println("Faculty name :: ");
            name = sc.next() ;
            System.out.println("Branch of Faculty :: ");
            branch = sc.next() ;
            System.out.println("Salary :: ");
            salary = sc.nextInt() ;

            f[i] = new Faculty(facultyID, name, salary, branch) ;
        }
        // For calculating the Total Salary of the Faculty .
        int totalSalary = 0 ;
        for(int i = 0 ; i < 5 ; ++i){
            totalSalary = totalSalary + f[i].salary ;
        }
        System.out.println("Total Salary = " + totalSalary);
        sc.close();
    }
}